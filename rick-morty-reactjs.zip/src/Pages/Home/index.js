import HeaderResponsive from '../../Components/HeaderResponsive'
import MainSection from '../../Components/MainSection';

function Home(){
    return(
        <div>
            <HeaderResponsive />
            <MainSection />
        </div>
    );
}

export default Home;